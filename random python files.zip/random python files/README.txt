These files are fake and was Copyrighted the script to a .py file to make it real and legit (but its actually fake).
You may have found this by
Some files are made by me and some files are Copyrighted.

You can see the .vbs in the "create .py errormessage by vbs" Folder if you want to not make it legit.
To create a one for yourself, Do these steps: 
1. You'll need to open the "shellcreatenotepad.reg" File in the "create .py errormessage by vbs" to add a context menu for opening notepad
2. Right-click on an empty space and click "Notepad"
3. You may copy from the other files and edit them to make your own or ask an AI like ChatGPT (https://chat.openai.com/chat), Login to your account by Google and type in "How do i make a Error DialogueBox with .py using Notepad?"
4. Then the ChatGPT AI will give an example to create a realistic ErrorMessage like me, Good Luck on that.

Thats all, You may start minding your business now.